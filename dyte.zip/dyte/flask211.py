Python 3.11.6 (tags/v3.11.6:8b6ee5b, Oct  2 2023, 14:57:12) [MSC v.1935 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> # Import Flask and Elasticsearch modules
... from flask import Flask, request
... from elasticsearch import Elasticsearch
... 
... # Create a Flask app and an Elasticsearch client
... app = Flask(__name__)
... es = Elasticsearch()
... 
... # Define a route for querying logs
... @app.route("/query", methods=["GET"])
... def query_logs():
...     # Get the query parameters from the request
...     q = request.args.get("q") # Full-text search query
...     filter = request.args.get("filter") # Field-based filter query
...     size = request.args.get("size") # Number of results to return
...     # Build the Elasticsearch query body
...     query_body = {"query": {}}
...     if q:
...         # Use a match query for full-text search
...         query_body["query"]["match"] = {"_all": q}
...     if filter:
...         # Use a term query for field-based filtering
...         query_body["query"]["term"] = filter
...     if size:
...         # Use a size parameter to limit the number of results
...         query_body["size"] = size
...     # Perform the query and get the results
...     results = es.search(index="logs", body=query_body)
...     # Return the results as JSON data
...     return results
... 
... # Run the app on port 3001
... if __name__ == "__main__":
...     app.run(port=3001)
