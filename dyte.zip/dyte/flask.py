Python 3.11.6 (tags/v3.11.6:8b6ee5b, Oct  2 2023, 14:57:12) [MSC v.1935 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> # Import Flask and Elasticsearch modules
... from flask import Flask, request
... from elasticsearch import Elasticsearch
... 
... # Create a Flask app and an Elasticsearch client
... app = Flask(__name__)
... es = Elasticsearch()
... 
... # Define a route for ingesting logs
... @app.route("/logs", methods=["POST"])
... def ingest_logs():
...     # Get the JSON data from the request body
...     data = request.get_json()
...     # Loop through the data and index each log in Elasticsearch
...     for log in data:
...         es.index(index="logs", body=log)
...     # Return a success message
...     return "Logs ingested successfully"
... 
... # Run the app on port 3000
... if __name__ == "__main__":
